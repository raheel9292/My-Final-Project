<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login form</title>
  <link rel="stylesheet" href="copy2.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<body>
  <div class="container">
    <div class="container3">
      <div class="container1">
        <div class="box1">
          <h1>POETRY"</h1>
        </div>
        <div class="box2">
          <ul>
            <a href="#">Home</a>
            <a href="#">Products</a>
            <a href="#">Our Story</a>
            <a href="#">Contact</a>
          </ul>
        </div>
        <div class="box3">
          <div class="box4">
            <img src="image/2811806.png" alt="">
          </div>
          <div class="box4">
            <img src="image/1170678.png" alt="">
          </div>
        </div>
        </div>
 
<div class="container4">
  <div class="box5"></div>
  <div class="box6">
    <div class="box7">
      <h2>Login Form</h2>
      <div class="hr">
        <hr>
        </div>
      <form action="form.php" method="post">
        <br>
        <!-- <label for="name">Username</label><br>
        <input type="text" id="name" placeholder="username" required> <br><br>
      <label for="email">Email</label> 
      <input type="email" id="email" placeholder="email" required><br> <br>

      <label for="password">Password</label><
      <input type="password" id="password" placeholder="password" required> <br><br> -->

      <label for="name">Username:</label>
            <input type="text" id="name" name="name" required><br><br>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br><br>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br><br>
            
           
      <input class="input1"  type="checkbox" id="Remember" required>
      <label class="lebel1" for="Remember">Remember me</label>

         <h3>Forget password   <a style="padding-left: 5px; color: black;font-size: 11px;" href="#">Click here</a> </h3>
        <div>
          <button type="submit">Login</button >
        </div>

        <input class="input1"  type="checkbox" id="term & condition" required>
        <label class="lebel1" for="Remember">I have agree the</label>

       <a class="a1" style="padding-left: 15px; color: black;font-size: 12px;" href="#">Term And Condition</a>
      <h5>Don't have an account <a style="color: black;padding-left: 5px;" href="#">SignUp</a></h5> 
      <div class="container5">
       <div class="box7"></div>
       <div class="box9">
        <h6> or connect with</h6>
       </div>
       <div class="box8"></div>
      </div> 
     
<div class="container6">
  <div class="box10">
    <img src="image/3128304 (1).png" alt="">
  </div>
  <div class="box10">
    <img src="image/300221.png" alt="">
  </div>
</div>


      </form>
      
      
    
      </div>




      
   
    </div>
  </div>
</div>







    </div>
  
    <!-- <div class="container2">
      <img src="image/images (1).jpeg" alt="">
    </div> -->
  </div>
</body>
</html>

